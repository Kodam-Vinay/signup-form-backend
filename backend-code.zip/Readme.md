=> installed "@types/node" for use node methods like require
=> npm i typescript ts-node nodemon --save-dev => Add typescript and ts-node for run typescript on the NodeJS.
=> installed different types of dependencies for validaton of typescript @types/bcrypt, @types/cors, @types/jsonwebtoken,@types/nodemailer, and @types/validator": "^13.11.9
